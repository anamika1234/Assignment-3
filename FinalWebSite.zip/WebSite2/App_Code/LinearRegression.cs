﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for LinearRegression
/// </summary>
public class LinearRegression
{
    public double Temperature { get; set; }
    public DateTime requiredDate { get; set; }
    public int TimeInHr { get; set; }
    public int Month { get; set; }
    public double Consumption { get; set; }
    public int area_floor { get; set; }
    public double base_hr_usage { get; set; }
    public double Sea_Level_PressureIn { get; set; }
    public double Wind_SpeedMPH { get; set; }
    public int WindDirDegrees { get; set; }




    public LinearRegression()
    {
        
    }
}