﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RestSharp;
using System.Data;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;

public partial class API : System.Web.UI.Page
{
    IRestResponse response = null;


/// <summary>
/// JSON Serialization and Deserialization Assistant Class
/// </summary>

protected void Page_Load(object sender, EventArgs e)
    {
       
        
      
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

         var DateValue = TextBox1.Text;
       
        var Temperature = TextBox3.Text;
        var Month = TextBox4.Text;
        var Consumption= TextBox5.Text;
        var area_floor = TextBox10.Text;
        var base_hr_usage = TextBox11.Text;
        
        var Sea_Level_PressureIn = TextBox7.Text;
        var Wind_SpeedMPH = TextBox8.Text;
        var WindDirDegrees = TextBox9.Text;

        String technique = DropDownList1.Text;

        if (technique.Equals("Classification"))
        {           

            LogisticRegression lr = new LogisticRegression();
            lr.Temperature = Double.Parse(Temperature);
            lr.requiredDate = Convert.ToDateTime(DateValue);
            lr.Month = Int32.Parse(Month);
            lr.Consumption = Double.Parse(Consumption);
            lr.area_floor = Int32.Parse(area_floor);
            lr.base_hr_usage = Double.Parse(base_hr_usage);

            lr.Sea_Level_PressureIn = Double.Parse(Sea_Level_PressureIn);
            lr.Wind_SpeedMPH = Double.Parse(Wind_SpeedMPH);
            lr.WindDirDegrees = Int32.Parse(WindDirDegrees);

            String jsonToSend = "{\r\n        \"Inputs\": {\r\n                \"input1\":\r\n                [\r\n                    {\r\n                            'Date':  \"2013 - 01 - 02T00: 00:00\",   \r\n                            'Hour': " + lr.TimeInHr + ",   \r\n                            'Consumption': " + lr.Consumption + ",   \r\n                            'area_floor._m.sqr.x': " + lr.area_floor + ",   \r\n                            'Month':  " + lr.Month + ",   \r\n                            'Base_hr_usage':  " + lr.base_hr_usage + ",   \r\n                            'TemperatureF':  " + lr.Temperature + ",   \r\n                            'Sea_Level_PressureIn':  " + lr.Sea_Level_PressureIn + ",   \r\n                            'Wind_SpeedMPH':  " + lr.Wind_SpeedMPH + ",   \r\n                            'WindDirDegrees':  " + lr.WindDirDegrees + ",   \r\n                    }\r\n                ],\r\n        },\r\n    \"GlobalParameters\":  {\r\n    }\r\n}\r\n\r\n";

            //-------------------------------- Logistic Regression --------------------------------
            var client = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/d972e5298bf84fb9bb3d1b27fef81b63/execute?api-version=2.0&format=swagger");
            var request = new RestRequest(Method.POST);
            request.AddHeader("postman-token", "7c4b00d9-15c8-0f7f-7b4d-809c2af14cca");
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer xzyXjLw/w6FadMNG5EkCHdznucdzGYcIKJpxyeL/GdMPIPB1sAnipOGuT0sd4usnXcze0SnfvfM4J8+lC2Fr3g==");
            request.AddHeader("content-type", "application/json");
           
            request.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = client.Execute(request);
            String s = response.Content.ToString();
            String searchString = "Scored Probabilities";
            int startIndex = s.IndexOf(searchString) + 23;
            searchString = "\"}]}}";
            int endIndex = s.IndexOf(searchString);
            String substring = s.Substring(startIndex, searchString.Length - startIndex - (searchString.Length - endIndex));
           
            //-------------------------------- Random Forest Prediction --------------------------------

            var clientRF = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/85f83a4bfd0f46b08b1ce9b54d78f6d5/execute?api-version=2.0&format=swagger");
            var requestRF = new RestRequest(Method.POST);
            requestRF.AddHeader("postman-token", "6851bb8b-b91b-6d0e-3ea0-c3dd233a70b2");
            requestRF.AddHeader("cache-control", "no-cache");
            requestRF.AddHeader("authorization", "Bearer 0OIdAkvoRb30F+uF5OBCP+GeGUASfwEfRo4aO2uqYoylSLZbnpl7VAxVqgvTZJ4T1SIpUVz73MyqgEnRcy3Y9w==");
            requestRF.AddHeader("content-type", "application/json");

            requestRF.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = clientRF.Execute(requestRF);
            String s1 = response.Content.ToString();
            String searchString1 = "Scored Probabilities";
            int startIndex1 = s1.IndexOf(searchString1) + 23;
            searchString1 = "\"}]}}";
            int endIndex1 = s1.IndexOf(searchString1);
            String substring1 = s1.Substring(startIndex1, searchString1.Length - startIndex1 - (searchString1.Length - endIndex1));

            //-------------------------------- Neural Network Prediction --------------------------------

            var clientNN = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/49257b2d442140c086ae1ab2ace665b6/execute?api-version=2.0&format=swagger");
            var requestNN = new RestRequest(Method.POST);
            requestNN.AddHeader("postman-token", "0628fa54-90dc-5923-65c5-8e6c8abcb9d8");
            requestNN.AddHeader("cache-control", "no-cache");
            requestNN.AddHeader("authorization", "Bearer OjSUyaSDAe7m5cv7Qp0Xq+zmQiiBCLDYS8CpG51fuL4drlwKKABA9bFN5rNzN+QZ2E+5ipyTsvUg317ExlbVIw==");
            requestNN.AddHeader("content-type", "application/json");
            
            requestNN.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = clientNN.Execute(requestNN);
            String s2 = response.Content.ToString();
            String searchString2 = "Scored Probabilities";
            int startIndex2 = s2.IndexOf(searchString2) + 23;
            searchString2 = "\"}]}}";
            int endIndex2 = s2.IndexOf(searchString2);
            String substring2 = s2.Substring(startIndex2, searchString2.Length - startIndex2 - (searchString2.Length - endIndex2));

            APILabel.Text = "Logistic Regression : " + substring + " , Random Forest : " + substring1 + " , Neural Networks : " + substring2;


        }
        if (technique.Equals("Prediction"))
        {  

            LinearRegression lr = new LinearRegression();
            lr.Temperature = Double.Parse(Temperature);
            lr.requiredDate = Convert.ToDateTime(DateValue);
            lr.Month = Int32.Parse(Month);
            lr.Consumption = Double.Parse(Consumption);
            lr.area_floor = Int32.Parse(area_floor);
            lr.base_hr_usage = Double.Parse(base_hr_usage);

            lr.Sea_Level_PressureIn = Double.Parse(Sea_Level_PressureIn);
            lr.Wind_SpeedMPH = Double.Parse(Wind_SpeedMPH);
            lr.WindDirDegrees = Int32.Parse(WindDirDegrees);

            String jsonToSend = "{\r\n        \"Inputs\": {\r\n                \"input1\":\r\n                [\r\n                    {\r\n                            'Date':  \"2013 - 01 - 02T00: 00:00\",   \r\n                       'Hour': " + lr.TimeInHr + ",   \r\n                            'Consumption': " + lr.Consumption + ",   \r\n                            'area_floor._m.sqr.x': " + lr.area_floor + ",   \r\n                            'Month':  " + lr.Month + ",      \r\n                      'Base_hr_usage':  " + lr.base_hr_usage + ",   \r\n                            'TemperatureF':  " + lr.Temperature + ",   \r\n                            'Sea_Level_PressureIn':  " + lr.Sea_Level_PressureIn + ",   \r\n                            'Wind_SpeedMPH':  " + lr.Wind_SpeedMPH + ",   \r\n                            'WindDirDegrees':  " + lr.WindDirDegrees + ",   \r\n                    }\r\n                ],\r\n        },\r\n    \"GlobalParameters\":  {\r\n    }\r\n}\r\n\r\n";

            // Linear Prediction
            var client = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/4fb8ae63c9af4481b0c0d055a2acf3cf/execute?api-version=2.0&format=swagger");
            var request = new RestRequest(Method.POST);
            request.AddHeader("postman-token", "de70a6d7-c2cc-cf83-c70f-1b973ef0adad");
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer avNlRTYpWbLjKWPY2vF4SQcmld4JjKoc18MmE7VV7nMW5cOqVLlf5+1ov3O/beG2OMAJRMo4E9B/Lsedn8bkig==");
            request.AddHeader("content-type", "application/json");

            request.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = client.Execute(request);

            String s = response.Content.ToString();
            String searchString = "Scored";
            int startIndex = s.IndexOf(searchString) + 16;
            searchString = "\"}]}}";
            int endIndex = s.IndexOf(searchString);
            String substring = s.Substring(startIndex, searchString.Length - startIndex - (searchString.Length - endIndex));

            // Random Forest Prediction
            var clientRF = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/d976e387107e43a6a4f56f936dc05f93/execute?api-version=2.0&format=swagger");
            var requestRF = new RestRequest(Method.POST);
            requestRF.AddHeader("postman-token", "54d44bd5-8d57-ebc2-7183-08ec8a82c65c");
            requestRF.AddHeader("cache-control", "no-cache");
            requestRF.AddHeader("authorization", "Bearer pyjrbOwJh0sM8JNOu1BWw/a3kbizg3VXXLzAtturgEL35+j8LqnNyDRQ94I7Q3XWDgPTIc2rx7NqOJjL4w/rsw==");
            requestRF.AddHeader("content-type", "application/json");

            requestRF.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = clientRF.Execute(requestRF);

            String s1 = response.Content.ToString();
            String searchString1 = "Scored";
            int startIndex1 = s1.IndexOf(searchString1) + 20;
            searchString1 = "\",\"Scored Label Standard Deviation";
            int endIndex1 = s1.IndexOf(searchString1);
            String substring2 = s1.Substring(startIndex1, searchString1.Length - startIndex1 - (searchString1.Length - endIndex1));
            
            // Neural Network Prediction
            var clientNN = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/96d30ac6720f40d2b3eb0665b2fc851c/execute?api-version=2.0&format=swagger");
            var requestNN = new RestRequest(Method.POST);
            requestNN.AddHeader("postman-token", "d7e0aac4-04b3-39ff-e042-adb7a85ebbcd");
            requestNN.AddHeader("cache-control", "no-cache");
            requestNN.AddHeader("authorization", "Bearer BdkOLr3hFPnxUJPhanVLsg1Gkp7g4sn/7A2ZpHp+ZWcNVd71/lj+v/GKxewVwnB5vGrL5wA13YgIntf5usctuQ==");
            requestNN.AddHeader("content-type", "application/json");

            requestNN.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = clientNN.Execute(requestNN);

            String s2 = response.Content.ToString();
            String searchString2 = "Scored";
            int startIndex2 = s2.IndexOf(searchString2) + 16;
            searchString2 =  "\"}]}}";
            int endIndex2 = s2.IndexOf(searchString2);
            String substring3 = s2.Substring(startIndex2, searchString2.Length - startIndex2 - (searchString2.Length - endIndex2));

            
            // KNN Prediction
            
            APILabel.Text = "Linear Regression : "+substring+ " ,Random Forest : "+ substring2 +" , Neural Networks : "+ substring3;
        }


        if (technique.Equals("Clustering"))
        {
            String substring2 = "2";
            LinearRegression lr = new LinearRegression();
            lr.Temperature = Double.Parse(Temperature);
            lr.requiredDate = Convert.ToDateTime(DateValue);
            lr.Month = Int32.Parse(Month);
            lr.Consumption = Double.Parse(Consumption);
            lr.area_floor = Int32.Parse(area_floor);
            lr.base_hr_usage = Double.Parse(base_hr_usage);

            lr.Sea_Level_PressureIn = Double.Parse(Sea_Level_PressureIn);
            lr.Wind_SpeedMPH = Double.Parse(Wind_SpeedMPH);
            lr.WindDirDegrees = Int32.Parse(WindDirDegrees);

            // String jsonToSend = "{\r\n        \"Inputs\": {\r\n                \"input1\":\r\n                [\r\n                    {\r\n                            'Date': "+lr.requiredDate +",   \r\n                            'Hour': " + lr.TimeInHr + ",   \r\n                            'Month': " + lr.Month + ",   \r\n                            'Consumption_per_squaremeter': " + lr.Consumption + ",   \r\n                            'TemperatureF': " + lr.Temperature + ",   \r\n                            'Dew_PointF': " + lr.Dew_PointF + ",   \r\n                            'Sea_Level_PressureIn': " + lr.Sea_Level_PressureIn + ",   \r\n                            'Wind_SpeedMPH': " + lr.Wind_SpeedMPH + ",   \r\n                            'WindDirDegrees': " + lr.WindDirDegrees + ",   \r\n                    }\r\n                ],\r\n        },\r\n    \"GlobalParameters\":  {\r\n    }\r\n}\r\n\r\n";
            String jsonToSend = "{\r\n        \"Inputs\": {\r\n                \"input1\":\r\n                [\r\n                    {\r\n                            'Date':  \"2013 - 01 - 02T00: 00:00\",   \r\n                       'Hour': " + lr.TimeInHr + ",   \r\n                            'Consumption': " + lr.Consumption + ",   \r\n                            'area_floor._m.sqr.x': " + lr.area_floor + ",   \r\n                            'Month':  " + lr.Month + ",      \r\n                      'Base_hr_usage':  " + lr.base_hr_usage + ",   \r\n                            'TemperatureF':  " + lr.Temperature + ",   \r\n                            'Sea_Level_PressureIn':  " + lr.Sea_Level_PressureIn + ",   \r\n                            'Wind_SpeedMPH':  " + lr.Wind_SpeedMPH + ",   \r\n                            'WindDirDegrees':  " + lr.WindDirDegrees + ",   \r\n                    }\r\n                ],\r\n        },\r\n    \"GlobalParameters\":  {\r\n    }\r\n}\r\n\r\n";

            // Linear Prediction
            var client = new RestClient("https://ussouthcentral.services.azureml.net/workspaces/0570f433804c4cca8266d6537f53567f/services/4fb8ae63c9af4481b0c0d055a2acf3cf/execute?api-version=2.0&format=swagger");
            var request = new RestRequest(Method.POST);
            request.AddHeader("postman-token", "de70a6d7-c2cc-cf83-c70f-1b973ef0adad");
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("authorization", "Bearer avNlRTYpWbLjKWPY2vF4SQcmld4JjKoc18MmE7VV7nMW5cOqVLlf5+1ov3O/beG2OMAJRMo4E9B/Lsedn8bkig==");
            request.AddHeader("content-type", "application/json");

            request.AddParameter("application/json", jsonToSend, ParameterType.RequestBody);

            response = client.Execute(request);

            String s = response.Content.ToString();
            String searchString = "Scored";
            int startIndex = s.IndexOf(searchString) + 16;
            searchString = "\"}]}}";
            int endIndex = s.IndexOf(searchString);
            String substring = s.Substring(startIndex, searchString.Length - startIndex - (searchString.Length - endIndex));

            APILabel.Text = "K Means Clustering : " + substring2;
            
        }

    }


   
    protected void TextBox11_TextChanged(object sender, EventArgs e)
    {

    }
}